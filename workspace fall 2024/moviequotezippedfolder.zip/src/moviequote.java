// luke 8-16 movie quote
public class moviequote {

	public static void main(String[] args) {
		System.out.println("The path of the righteous man is beset on all sides by the inequities of the selfish and the tyranny of evil men.");
		System.out.println("pulp fiction");
		System.out.println("jules winnfield");
		System.out.println("1994");
	

	}

}
